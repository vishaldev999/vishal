import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'getInitials'
})
export class GetInitialsPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
