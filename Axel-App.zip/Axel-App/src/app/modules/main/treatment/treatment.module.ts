import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CallListComponent } from './call-list/call-list.component';
import { PendingComponent } from './pending/pending.component';
import { CompletedComponent } from './completed/completed.component';



@NgModule({
  declarations: [
    DashboardComponent,
    CallListComponent,
    PendingComponent,
    CompletedComponent
  ],
  imports: [
    CommonModule
  ]
})
export class TreatmentModule { }
