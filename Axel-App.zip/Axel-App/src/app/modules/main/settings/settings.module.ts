import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './users/users.component';
import { PracticesComponent } from './practices/practices.component';
import { EligibilityComponent } from './eligibility/eligibility.component';
import { EngagementComponent } from './engagement/engagement.component';
import { FormsComponent } from './forms/forms.component';
import { GoalsComponent } from './goals/goals.component';
import { MessagingComponent } from './messaging/messaging.component';
import { PayementsComponent } from './payements/payements.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { SchedulingComponent } from './scheduling/scheduling.component';
import { TreatmentComponent } from './treatment/treatment.component';
//import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [
    UsersComponent,
    PracticesComponent,
    EligibilityComponent,
    EngagementComponent,
    FormsComponent,
    GoalsComponent,
    MessagingComponent,
    PayementsComponent,
    ReviewsComponent,
    SchedulingComponent,
    TreatmentComponent,
    //SharedModule
  ],
  imports: [
    CommonModule
  ]
})
export class SettingsModule { }
