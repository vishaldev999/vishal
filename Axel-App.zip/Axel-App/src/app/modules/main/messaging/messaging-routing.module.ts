import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InboxComponent } from './inbox/inbox.component';
import { MassSmsComponent } from './mass-sms/mass-sms.component';

const routes: Routes = [
  { path: 'inbox', component: InboxComponent },
  { path: 'mass', component: MassSmsComponent },
  { path: '',  pathMatch:'full', redirectTo:'inbox' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MessagingRoutingModule { }
