import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-practice',
  templateUrl: './practice.component.html',
  styleUrls: ['./practice.component.scss']
})
export class PracticeComponent implements OnInit {
  sidebarVisible: any;

  countries: any[] = [];;

  selectedCountries!: any;

  date!: Date[];

  data: any = {};

  options: any = {};
  tablepractice: any[] = []
  tooltipValue: string = "";
  ngOnInit() {
        this.countries = [
            { name: 'Australia', code: 'AU' },
            { name: 'Brazil', code: 'BR' },
            { name: 'China', code: 'CN' },
            { name: 'Egypt', code: 'EG' },
            { name: 'France', code: 'FR' },
            { name: 'Germany', code: 'DE' },
            { name: 'India', code: 'IN' },
            { name: 'Japan', code: 'JP' },
            { name: 'Spain', code: 'ES' },
            { name: 'United States', code: 'US' }
        ];

        const documentStyle = getComputedStyle(document.documentElement);
        const textColor = documentStyle.getPropertyValue('--text-color');

        this.data = {
           
            datasets: [
                {
                    data: [300, 50, 50, 60],
                    backgroundColor: [documentStyle.getPropertyValue('--chart-a'),documentStyle.getPropertyValue('--chart-b'), documentStyle.getPropertyValue('--chart-c'), documentStyle.getPropertyValue('--chart-d')],
                    
                }
            ]
        };


        this.options = {
            cutout: '65%',
            plugins: {
                legend: {
                    labels: {
                        color: textColor
                    }
                }
            }
        };


        this.tablepractice = [
          {
            practiceName: {                    
              name: 'Practice 1',
              location: '401 E Sonterra Blvd, San Antonio, TX 78258'
            },
            grossProduction: '$356,877.06',
            totalAdjustments: '$(356,877.06)',
            adjustedProduction: '$356,877.06',
            pastDueAgingAR:'$356,877.06',
            totalCollections:'$356,877.06',
            scheduledProduction:'$356,877.06',
            unscheduledTreatment:'$356,877.06',
            unscheduledHygiene:'$356,877.06'
          },
          {
            practiceName: {                    
              name: 'Practice 2',
              location: '401 E Sonterra Blvd, San Antonio, TX 78258'
            },
            grossProduction: '$356,877.06',
            totalAdjustments: '$(356,877.06)',
            adjustedProduction: '$356,877.06',
            pastDueAgingAR:'$356,877.06',
            totalCollections:'$356,877.06',
            scheduledProduction:'$356,877.06',
            unscheduledTreatment:'$356,877.06',
            unscheduledHygiene:'$356,877.06'
          },
          {
            practiceName: {                    
              name: 'Practice 3',
              location: '401 E Sonterra Blvd, San Antonio, TX 78258'
            },
            grossProduction: '$356,877.06',
            totalAdjustments: '$(356,877.06)',
            adjustedProduction: '$356,877.06',
            pastDueAgingAR:'$356,877.06',
            totalCollections:'$356,877.06',
            scheduledProduction:'$356,877.06',
            unscheduledTreatment:'$356,877.06',
            unscheduledHygiene:'$356,877.06'
          },
          {
            practiceName: {                    
              name: 'Practice 4',
              location: '401 E Sonterra Blvd, San Antonio, TX 78258'
            },
            grossProduction: '$356,877.06',
            totalAdjustments: '$(356,877.06)',
            adjustedProduction: '$356,877.06',
            pastDueAgingAR:'$356,877.06',
            totalCollections:'$356,877.06',
            scheduledProduction:'$356,877.06',
            unscheduledTreatment:'$356,877.06',
            unscheduledHygiene:'$356,877.06'
          },
          {
            practiceName: {                    
              name: 'Practice 5',
              location: '401 E Sonterra Blvd, San Antonio, TX 78258'
            },
            grossProduction: '$356,877.06',
            totalAdjustments: '$(356,877.06)',
            adjustedProduction: '$356,877.06',
            pastDueAgingAR:'$356,877.06',
            totalCollections:'$356,877.06',
            scheduledProduction:'$356,877.06',
            unscheduledTreatment:'$356,877.06',
            unscheduledHygiene:'$356,877.06'
          },
          {
            practiceName: {                    
              name: 'Practice 5',
              location: '401 E Sonterra Blvd, San Antonio, TX 78258'
            },
            grossProduction: '$356,877.06',
            totalAdjustments: '$(356,877.06)',
            adjustedProduction: '$356,877.06',
            pastDueAgingAR:'$356,877.06',
            totalCollections:'$356,877.06',
            scheduledProduction:'$356,877.06',
            unscheduledTreatment:'$356,877.06',
            unscheduledHygiene:'$356,877.06'
          }
        ];
    }

    

  public practiceList = [
    {
      practiceName: 'Brooks-Ortho',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Brooks-Pedo',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Cibolo-Ortho',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Cibolo-Pedo',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Culebra-Ortho',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    },
    {
      practiceName: 'Culebra-Pedo',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    }
  ];
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      crosshair: {
          width: 100,
          color: 'rgba(204,211,255,0.25)'
      },
      lineWidth: 0,
      minorGridLineWidth: 0,
      lineColor: 'transparent',
  },
  yAxis: {
    title: { text: '' }
},

  title: { text: '' },   
  subtitle : { text: '' },
  credits: { enabled: false },

    series: [{
      showInLegend: false, 
      name: 'Ocean transport',
      data: [400, 600, 630, 800, 820, 860, 900,1000,1020,800,900,1000],
      type: 'spline',
      color: '#0acadc',
    }, {
      showInLegend: false, 
      name: 'Households',
      data: [300, 500, 530, 700, 720, 760, 800,900,920,700,800,900],
      type: 'spline',
      color:'#9267B4',
      marker: {
        symbol: 'circle',
      }
    }, {
      showInLegend: false, 
      name: 'table',
      data: [300, 500, 500, 300, 500, 500, 300,0,500,100,50,300],
      type: 'column',
      color:'rgba(255, 117, 151, 0.15)',
      borderRadius: 100,
      borderWidth: 0,
      
    }, {
      showInLegend: false, 
      name: 'fourth table line',
      data: [0, 50, 125, 300, 320, 360, 400,0,620,400,500,600],
      type: 'spline',
      marker: {
        symbol: 'circle',
      },
      color:'#FABB87',
      borderRadius: 20,
      borderWidth: 0,
      
    }],
    
    tooltip: {
      positioner(labelWidth, labelHeight, point) {
        return {
          x: point.plotX - 104,
          y: point.plotY -180 ,
        };
      },
    
      shadow: false,
      shared:true,
      useHTML: true,
      outside:true,
      backgroundColor: '#fff',
      borderRadius: 10,
      formatter: function (response) {
        //console.log(response);
        let tooltip = '<div class="chart_tooltip Jan">';
        tooltip += '<h4>Jan 2023</h4>';
        tooltip += '<div class = "tooltip-content">';
        tooltip += '<div class="item gross"><p><b></b><span>Gross Production</span></p><h6>$0</h6></div>';
        tooltip += '<div class="item adjusted"><p><b></b><span>Adjusted Production</span></p><h6>$0</h6></div>';
        tooltip += '<div class="item total"><p><b></b><span>Total Adjustments</span></p><h6>$0</h6></div>';
        tooltip += '<div class="item scheduled"><p><b></b><span>Scheduled Production</span></p><h6>$0</h6></div>';
        tooltip += '</div>';
        tooltip += '</div>'
        return tooltip; 
      }
  }
  
}




  isShowDivIf = false;  
    
  // toggleDisplayDivIf() {  
  //   this.isShowDivIf = true;  
  // }  
  removeDisplayDivIf() {  
    this.tooltipValue = '';  
  }  

  toggleDisplayDivIf(tootipitem: string) {
    if (this.tooltipValue == tootipitem)
      this.tooltipValue = "";
    else
      this.tooltipValue = tootipitem;
  }
}
