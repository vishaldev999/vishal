import { Component } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent {

  navValue: string = ""
  fullwidth: boolean = false;
  menuId: string = '';

  toggleFullwidth(fullwidth: boolean) {
    this.fullwidth = fullwidth;
  }

  menuSelect(menuid: string) {
    this.menuId = menuid;
  }

  expandDropdown(navitem: string) {
    if (this.navValue == navitem)
      this.navValue = "";
    else
      this.navValue = navitem;
  }
}
