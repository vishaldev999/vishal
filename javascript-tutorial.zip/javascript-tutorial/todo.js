function getAndUpdate() {
    console.log("updating list..")

    tit = document.getElementById("title").value;
    des = document.getElementById("description").value;

    if (des == "") {
        document.getElementById("title").style.border = "1px solid red";
        document.getElementById("description").style.border = "1px solid red";
        // alert("Input must be filled out");
        return false;

    }
    else {
        document.getElementById("title").style.border = "1px solid #ced4da";
        document.getElementById("description").style.border = "1px solid #ced4da";
    }

    if (localStorage.getItem('itemsJson') == null) {

        itemJsonArray = [];
        itemJsonArray.push([tit, des]);

        localStorage.setItem('itemsJson', JSON.stringify(itemJsonArray))

    } else {

        itemJsonArrayStr = localStorage.getItem('itemsJson');
        itemJsonArray = JSON.parse(itemJsonArrayStr);

        itemJsonArray.push([tit, des]);
        localStorage.setItem('itemsJson', JSON.stringify(itemJsonArray))
    }
    update();
}
function update() {

    if (localStorage.getItem('itemsJson') == null) {

        itemJsonArray = [];
        localStorage.setItem('itemsJson', JSON.stringify(itemJsonArray))

    } else {

        itemJsonArrayStr = localStorage.getItem('itemsJson');
        itemJsonArray = JSON.parse(itemJsonArrayStr);
    }

    let tableBody = document.getElementById("tableBody");

    let str = "";

    itemJsonArray.forEach((element, index) => {
        `<h1>test<h1/>`

        str += `<tr>
                    <td>
                        ${index + 2}
                    </td>
                    <td>
                        ${element[0]}
                    </td>
                    <td >
                        ${element[1]}
                    </td>
                    <th>
                        <button class="btn btn-primary small" onclick="deleted(${index})">Delete</button>
                    </th>
                </tr>`

    });
    tableBody.innerHTML = str;


    // populate the TABLE
}
add = document.getElementById("add");

add.addEventListener("click", getAndUpdate);
update();

function deleted(itemIndex) {
    if (confirm("Do you really want to delete?"))
        console.log("Delete", itemIndex);


    itemJsonArrayStr = localStorage.getItem('itemsJson');

    itemJsonArray = JSON.parse(itemJsonArrayStr);
    itemJsonArray.splice(itemIndex, 1)
    localStorage.setItem('itemsJson', JSON.stringify(itemJsonArray))
    update();
}

function clearStorage() {

    if (confirm("Do you really want to delete?"))
        console.log("Clearing the local storage ")
    localStorage.clear();
    update();
}


// table tr default

let table = document.getElementById("todoTable");
let row = table.insertRow(-1);
// table cells
let c1 = row.insertCell(0);
let c2 = row.insertCell(1);
let c3 = row.insertCell(2);
let c4 = row.insertCell(3);
// Add data to c1 and c2 ...
c1.innerText = "1"
c2.innerText = "Item Title Here .. !"
c3.innerText = "Lorem Ipsum Generators"
c4.innerHTML = "<button class='btn btn-primary small' disabled>Delete</button>"
