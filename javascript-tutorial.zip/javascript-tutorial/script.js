// 1. ways to print in javascript

// console.log("Hello World");
// alert("alert");
// document.write("Hello World")

// clear error in console
// console.clear();

// 2. Javascript console API
// console.log("Hello World");
// console.warn("\\//Warning\\//")
// console.error("This is an error ");

// 3. JS Variable
// what are Variable? - container to store data values

var number1 = 5;
var number2 = 10
// console.log(number1 + number2);

// 4. Data types in javascript

/*************************/
// Number

var num1 = 22.2;
var num2 = 10;

/*************************/
// String

var str1 = "This is a string";
var str2 = 'this is a alose string';

/*************************/
// object

var marks = {
    ravi: 80,
    rahul: 70,
    Mj: 80,
    vishal: 99.97,

}
// console.log(marks);

// Boolean
/*************************/

// var a = true;
// var b = false;

/*************************/
// Undefined

// var und;

// var und = undefined;
//  console.log(und);


/*************************/
// Null

var nl = null;

// Symbol

/*
At a very height level, there are two types of data types in JavaScript
1.Primitive data types: - number, string, boolean symbol undefined, null, ,
2.Reference data types : Object & Array
*/


// 2.Reference data types - Array
/*************************/

var arr = [1, 2, "string", 4, 8, 3, 5, 9, 7, 6];

// console.log(arr[4]);

/*************************/
// JS Operator

var a = 100;
var b = 2;

// console.log("A:100, B:10");
// console.log("The Value of a + b = ", a + b);
// console.log("The Value of a - b = ", a - b);
// console.log("The Value of a * b = ", a * b);
// console.log("The Value of a / b = ", a / b);


/*************************/
/*  Assignment Operators

Operator	Example	  Same As
=	        x = y	  x = y
+=	        x += y	  x = x + y
-=	        x -= y	  x = x - y
*=	        x *= y	  x = x * y
/=	        x /= y	  x = x / y
%=	        x %= y	  x = x % y
**=	        x **= y	  x = x ** y
*/

var c = b;
c += 2;
c -= 2;
c *= 2;
c /= 2;
c %= 2;
c **= 3;

// console.log(c)


/*************************/
// Comparison Operators

var x = 80;
var y = 80;
// console.log(x == y);
// console.log(x <= y);
// console.log(x >= y);
// console.log(x < y);
// console.log(x > y);

/*************************/
// Logical Comparison Operators

// && Operators - in && case both value are should be same(or true ). 

// console.log(true && true);
// console.log(true && false);
// console.log(false && true);
// console.log(false && false);

//or || Operators case one value shold be true
// console.log(true || true);
// console.log(true || false);
// console.log(false || true);
// console.log(false || false);

// Logical not (!) Operators

// console.log(!true);
// console.log(!false);

/*************************/
// simple function


function avg(a, b,) {
    c = (a + b) / 2;
    return c;
}
c1 = avg(4, 6);
c2 = avg(40, 60);

// console.log(c1, c2)


/*************************/
// Conditional Statements

var age = 34;

/*************************/
// Single if statement


// if (age > 18) {

//     console.log("You Can drink ")
// }


/*************************/

// if - else statemnt


// if (age > 18) {

//     console.log("You Can drink ")
// } else {

//     console.log("You can't drink ")

// }

/*************************/

/* var yAge = 34;
yAge = 27;
if (yAge > 32) {
    console.log("You are not a kid")
}
else if (yAge > 26) {
    console.log("Bache nhi rahe")

}
else if (yAge > 22) {
    console.log("Yes bache nhi rahe ")
}

else {
    console.log("Bache rahe")
}

console.log("End of ladder")

*/


/*************************/
// jacascript loops

// 1. for - loops through a block of code a number of times

// array iterate

// var newArry = [1, 2, 3, 4, 5, 6, 7]
// console.log(newArry);

// for (var i = 0; i < newArry.length; i++) {

//     if (i == 2) {
//         // break;
//         continue
//     }

//     console.log(newArry[i])

// }


/*************************/
// forEach loop

// newArry.forEach(function (element) {
//     console.log(element);

// });


/*************************/
// The While Loop


// let w = 0;

// while (w < newArry.length) {

//     console.log(newArry[1]);
//     w++;
// }


/*************************/
// The do While Loop

// do {
//     console.log(newArry[w])
//     w++
// } while (w < newArry.length);


// let myArr = ["Red", "Green", 34, null, true,]

/*Array Methods
/*************************/

// Array length
// Array toString()
// Array pop()
// Array push()
// Array shift()
// Array unshift()

// myArr.pop(); // remove last Array
// myArr.push("Vishal")
// myArr.shift()    
// myArr.unshift("vssss")

// myArr.sort();

// console.log(myArr);

// let sortMethod = ["3", "6", "9", "8", "5", "2", "1", "4", "7"]


// console.log("normal - Array ", sortMethod);

// let string = sortMethod.toString();
// let sort = sortMethod.sort();


// console.log("String Method", string, "Sort Method", sort);


/*String Methods
/*************************/


let testString = "myss name is vishal"
let test = testString.slice(3, 14)

// let replace = testString.replace("name", "MYname");

// console.log(replace);


// const fruits = ["Banana", "Orange", "Apple", "Kiwi"];
// fruits.splice(1, 2);
// console.log(fruits);


/*************************/
// JavaScript DOM Manipulation

let divElement = document.getElementById("blue-bg");
let addStyle = document.getElementById("demo");


if (divElement != null) {

    let getHeight = divElement.offsetHeight;
    console.log(divElement)
    addStyle.style.height = getHeight + 'px'

}


// create Element


if (addStyle) {
    let createEle = document.createElement('p');
    createEle.innerHTML = "This is created by js  "
    addStyle.appendChild(createEle);

}
// fixed header js

let header = document.getElementById("header");

if (header) {
    function scrollTopFunction() {

        if (document.documentElement.scrollTop > 50) {

            header.classList.add("mystyle");
            console.log("if working")

        } else {
            header.classList.remove("mystyle");
            console.log("else working")
        }

    }
    onscroll = function () {
        scrollTopFunction()
    };

}


// clock js

let timeElement = document.getElementById("time")
if (timeElement) {
    setInterval(() => {

        let a;
        let date;
        let time;
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };

        a = new Date;
        date = a.toLocaleDateString(undefined, options);
        time = a.getHours() + ':' + a.getMinutes() + ':' + a.getSeconds()
        console.log(date)

        timeElement.innerHTML = time + ` ` + `<strong>` + date + `</strong>`;
    }, 1000)

}

// switch case


let ct;

let ctValue = document.getElementById("switchCase");

function checkSwitchCase() {

    ct = document.getElementById("swInput").value;

    if (ct == "") {
        document.getElementById("sw-main").classList.add("error")

    } else {
        document.getElementById("sw-main").classList.remove("error")
        switch (parseInt(ct)) {

            case 45:

                ct = "The value of the switch Case title is <b>45</b> <br><br><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> "
                break;

            case 46:

                ct = "The value of the switch Case title is  <b>46</b> <br><br><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>"

                break;

            case 47:
                ct = "The value of the switch Case title is  <b>47</b> <br><br><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>"
                break;

            case 48:
                ct = "The value of the switch Case title is  <b>48</b> <br><br><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>"
                break;

            case 49:
                ct = "The value of the switch Case title is  <b>49</b> <br><br><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>"
                break;

            case 50:
                ct = "The value of the switch Case title is  <b>50</b> <br><br><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknowageMaker including versions of Lorem Ipsum.</p>"
                break;

            default:
                ct = `Sorry, Your CR No <b style="color:red;">[${ct}]</b>  doesn't match in our data base, please Try again 🙂  `
        }
    }

    ctValue.innerHTML = ct;

}

let dayCount = document.getElementById("dayId");

let day;
if (dayCount) {

    switch (new Date().getDay()) {
        case 0:
            day = "Sunday";

            break;
        case 1:
            day = "Monday";
            break;
        case 2:
            day = "Tuesday";
            break;
        case 3:
            day = "Wednesday";
            break;
        case 4:
            day = "Thursday";
            break;
        case 5:
            day = "Friday";
            break;
        case 6:
            day = "Saturday";

        default:
            text = "Looking forward to the Weekend";
    }
    dayCount.innerHTML = "Today is " + `<strong style="color:blue">` + day + `</strong>`;


}


// Practice set


/* Q :1 =>
 Create a variable a type string and try to add a number to it.
 */

let a1 = "vishal"
let b1 = 60

// console.log(typeof a1 + b1)

// Q-2 use typeof operator to find the data type of the sting in the last question.

// console.log(typeof (a1 + b1))


// Q-3  create a const object in javascript can you it to hold a number later   


const objectTest = {
    name: "vishal",
    section: 1,
    isPrinciple: false
}
objectTest['name'] = "Bhawani"
objectTest['isPrinciple'] = true;

// console.log(objectTest)