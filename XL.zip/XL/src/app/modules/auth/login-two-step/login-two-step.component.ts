import { Component } from '@angular/core';

@Component({
  selector: 'app-login-two-step',
  templateUrl: './login-two-step.component.html',
  styleUrls: ['./login-two-step.component.scss']
})
export class LoginTwoStepComponent {

}
