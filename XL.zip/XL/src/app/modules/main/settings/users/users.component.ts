import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  countries: any[] = [];
  tableusers: any[] = [];

  selectedCountries!: any;
  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];

  cities: any[] = [];
  selectedCities: any[] = [];

  filterUsers(event:any) {
    let filtered: any[] = [];
        let query = event.query;
        console.log(event)
        filtered = this.users.filter((e:any)=>{ return e.name.toLowerCase().indexOf(query.toLowerCase())!=-1});
        console.log(filtered)
        this.filteredUsers = filtered;
  }

  ngOnInit() {
    this.tableusers = [
      {
        username: {
          image: '../../assets/userimage.png',
          name: 'Pedro Becker',
          emailid: 'pedrobecker@meetaxle.com',
          usertype: ''
        },
        practiceaccess: 'Smiling Teeth Clinic (+3)',
        dateadded: 'Mar 1, 2022',
        status: 'Active',
        statusclass:'active'
    },
    {
      username: {
        image: '../../assets/userimage.png',
        name: 'Pedro Becker',
        emailid: 'pedrobecker@meetaxle.com',
        usertype: ''
      },
      practiceaccess: 'Smiling Teeth Clinic (+3)',
      dateadded: 'Mar 1, 2022',
      status: 'Active',
      statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: 'Global Admin'
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Inactive',
    statusclass:'inactive'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: 'Global Admin'
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Pending',
    statusclass:'pending'
  },
  {
    username: {
      image: '../../assets/userimage.png',
      name: 'Pedro Becker',
      emailid: 'pedrobecker@meetaxle.com',
      usertype: ''
    },
    practiceaccess: 'Smiling Teeth Clinic (+3)',
    dateadded: 'Mar 1, 2022',
    status: 'Active',
    statusclass:'active'
},
{
  username: {
    image: '../../assets/userimage.png',
    name: 'Pedro Becker',
    emailid: 'pedrobecker@meetaxle.com',
    usertype: ''
  },
  practiceaccess: 'Smiling Teeth Clinic (+3)',
  dateadded: 'Mar 1, 2022',
  status: 'Active',
  statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: 'Global Admin'
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Inactive',
statusclass:'inactive'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: 'Global Admin'
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
  username: {
    image: '../../assets/userimage.png',
    name: 'Pedro Becker',
    emailid: 'pedrobecker@meetaxle.com',
    usertype: ''
  },
  practiceaccess: 'Smiling Teeth Clinic (+3)',
  dateadded: 'Mar 1, 2022',
  status: 'Active',
  statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: 'Global Admin'
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Inactive',
statusclass:'inactive'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: 'Global Admin'
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
  username: {
    image: '../../assets/userimage.png',
    name: 'Pedro Becker',
    emailid: 'pedrobecker@meetaxle.com',
    usertype: ''
  },
  practiceaccess: 'Smiling Teeth Clinic (+3)',
  dateadded: 'Mar 1, 2022',
  status: 'Active',
  statusclass:'active'
},
{
username: {
  image: '../../assets/userimage.png',
  name: 'Pedro Becker',
  emailid: 'pedrobecker@meetaxle.com',
  usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: 'Global Admin'
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Inactive',
statusclass:'inactive'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: 'Global Admin'
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Active',
statusclass:'active'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
},
{
username: {
image: '../../assets/userimage.png',
name: 'Pedro Becker',
emailid: 'pedrobecker@meetaxle.com',
usertype: ''
},
practiceaccess: 'Smiling Teeth Clinic (+3)',
dateadded: 'Mar 1, 2022',
status: 'Pending',
statusclass:'pending'
}
    ];

    this.users = [
      {
       name:'Ashish Kaushik'
     },
     {
       name:'Nisar'
     },
     {
       name:'Rachel Etherington'
     },
     {
       name:'Anurag'
     },
     {
       name:'Abhishek'
     }
   ];

    this.countries = [
        { name: 'Australia', code: 'AU' },
        { name: 'Brazil', code: 'BR' },
        { name: 'China', code: 'CN' },
        { name: 'Egypt', code: 'EG' },
        { name: 'France', code: 'FR' },
        { name: 'Germany', code: 'DE' },
        { name: 'India', code: 'IN' },
        { name: 'Japan', code: 'JP' },
        { name: 'Spain', code: 'ES' },
        { name: 'United States', code: 'US' }
    ];

    this.cities = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' }
  ];
  }

  public practiceList = [
    {
      practiceName: 'Brooks-Ortho',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Brooks-Pedo',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Cibolo-Ortho',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Cibolo-Pedo',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Culebra-Ortho',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    },
    {
      practiceName: 'Culebra-Pedo',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    }
  ];
}
