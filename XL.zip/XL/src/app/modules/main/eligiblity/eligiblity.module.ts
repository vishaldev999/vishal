import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PendingComponent } from './pending/pending.component';
import { VerifiedComponent } from './verified/verified.component';
import { EligibilityRoutingModule } from './eligibility-routing.module';



@NgModule({
  declarations: [
    DashboardComponent,
    PendingComponent,
    VerifiedComponent
  ],
  imports: [
    CommonModule,
    EligibilityRoutingModule
  ]
})
export class EligiblityModule { }
