import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoadMapComponent } from './road-map/road-map.component';

const routes: Routes = [
  { path: 'road', component: RoadMapComponent },
  { path: '',  pathMatch:'full', redirectTo:'road' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalyticsRoutingModule { }
