import { Component } from '@angular/core';

@Component({
  selector: 'app-uts-employees',
  templateUrl: './uts-employees.component.html',
  styleUrls: ['./uts-employees.component.scss']
})
export class UtsEmployeesComponent {

  utsEmployees: any[] = [];
  employeeInsights: any[] = [];
  employeenSightsSidebar: boolean = false;


  ngOnInit() {

    // UTS by Employees Table Data

    this.utsEmployees = [

      {
        rankLevel: {
          position: 1,
          rank: "1st",
        },
        details: {
          shortName: 'LL',
          isShortName: false,
          fullName: 'Lois Lane',
          userPic: '../../../../../assets/Pedro.png',
          isUserPic: true
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 2,
          rank: "2nd",
        },
        details: {
          shortName: 'CK',
          isShortName: true,
          fullName: 'Clark Kent',
          userPic: '../../../../../assets/Pedro.png',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 3,
          rank: "3rd",
        },
        details: {
          shortName: 'HG',
          isShortName: false,
          fullName: 'Holly Golightlyt',
          userPic: '../../../../../assets/Pedro.png',
          isUserPic: true
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 4,
          rank: "4th",
        },
        details: {
          shortName: 'LT',
          isShortName: true,
          fullName: 'Liza T',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },

      {
        rankLevel: {
          position: 5,
          rank: "5th",
        },
        details: {
          shortName: 'HH',
          isShortName: true,
          fullName: 'Henry Higgins',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },

      {
        rankLevel: {
          position: 6,
          rank: "6th",
        },
        details: {
          shortName: 'MM',
          isShortName: true,
          fullName: 'Mary Magdalene',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 7,
          rank: "7th",
        },
        details: {
          shortName: 'LL',
          isShortName: true,
          fullName: 'Lois Lane',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },


    ];

    // end

    // Employee Insights Table Data

    this.employeeInsights = [


      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
    ];

    // end


  }

  onRightBar() {
    alert();
  }
}
