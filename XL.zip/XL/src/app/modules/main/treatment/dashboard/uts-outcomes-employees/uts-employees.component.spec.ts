import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UtsEmployeesComponent } from './uts-employees.component';

describe('UtsEmployeesComponent', () => {
  let component: UtsEmployeesComponent;
  let fixture: ComponentFixture<UtsEmployeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UtsEmployeesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UtsEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
