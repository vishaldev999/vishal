import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CallListComponent } from './call-list/call-list.component';
import { PendingComponent } from './pending/pending.component';
import { CompletedComponent } from './completed/completed.component';


const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'call', component: CallListComponent },
  { path: 'pending', component: PendingComponent },
  { path: 'completed', component: CompletedComponent },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TreatmentRoutingModule { }
