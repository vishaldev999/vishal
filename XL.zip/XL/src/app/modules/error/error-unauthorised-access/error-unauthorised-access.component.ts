import { Component } from '@angular/core';

@Component({
  selector: 'app-error-unauthorised-access',
  templateUrl: './error-unauthorised-access.component.html',
  styleUrls: ['./error-unauthorised-access.component.scss']
})
export class ErrorUnauthorisedAccessComponent {

}
