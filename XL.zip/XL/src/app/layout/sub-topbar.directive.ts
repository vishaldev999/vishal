import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appSubTopbar]'
})
export class SubTopbarDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }

}
