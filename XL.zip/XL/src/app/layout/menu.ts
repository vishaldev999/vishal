import { SubTopbarWithFilterComponent } from "./sub-topbar-with-filter/sub-topbar-with-filter.component";
import { SubTopbarComponent } from "./sub-topbar/sub-topbar.component";

export class MenuClass {
    menuList: any = [
        {
            id: 'M1', name: 'Analytics', icon: ` <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42814)">
                <path
                    d="M7.04163 22.75H3.24996C2.65413 22.75 2.16663 22.2625 2.16663 21.6667V10.8333C2.16663 10.2375 2.65413 9.75 3.24996 9.75H7.04163C7.63746 9.75 8.12496 10.2375 8.12496 10.8333V21.6667C8.12496 22.2625 7.63746 22.75 7.04163 22.75ZM14.8958 3.25H11.1041C10.5083 3.25 10.0208 3.7375 10.0208 4.33333V21.6667C10.0208 22.2625 10.5083 22.75 11.1041 22.75H14.8958C15.4916 22.75 15.9791 22.2625 15.9791 21.6667V4.33333C15.9791 3.7375 15.4916 3.25 14.8958 3.25ZM22.75 11.9167H18.9583C18.3625 11.9167 17.875 12.4042 17.875 13V21.6667C17.875 22.2625 18.3625 22.75 18.9583 22.75H22.75C23.3458 22.75 23.8333 22.2625 23.8333 21.6667V13C23.8333 12.4042 23.3458 11.9167 22.75 11.9167Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42814">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M1S1', name: 'Practice', url: 'analytics/practice', icon: '', subtopbar: SubTopbarComponent },
                { id: 'M1S2', name: 'Provider', url: 'analytics/provider', icon: '', subtopbar: SubTopbarWithFilterComponent },
                { id: 'M1S3', name: 'Region', url: 'analytics/region', icon: '' },
                { id: 'M1S4', name: 'Hygiene', url: 'analytics/hygiene', icon: '', subtopbar: SubTopbarWithFilterComponent },
            ]
        },
        {
            id: 'M2', name: 'Collections', icon: ` <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42747)">
                <path
                    d="M15.6 6.49967L15.34 5.19967C15.2425 4.70134 14.7984 4.33301 14.2784 4.33301H6.50002C5.90419 4.33301 5.41669 4.82051 5.41669 5.41634V21.6663C5.41669 22.2622 5.90419 22.7497 6.50002 22.7497C7.09585 22.7497 7.58335 22.2622 7.58335 21.6663V15.1663H13.65L13.91 16.4663C14.0075 16.9755 14.4517 17.333 14.9717 17.333H20.5834C21.1792 17.333 21.6667 16.8455 21.6667 16.2497V7.58301C21.6667 6.98717 21.1792 6.49967 20.5834 6.49967H15.6Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42747">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M2S1', name: 'Dashboard', url: 'collection/dashboard', icon: '' },
                { id: 'M2S2', name: 'Collections', url: 'collection/collections', icon: '' },
            ]
        },
        {
            id: 'M3', name: 'Eligibility', icon: ` <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42750)">
                <path
                    d="M12.1225 1.47301L4.53917 4.84217C3.75917 5.18884 3.25 5.96884 3.25 6.82467V11.9163C3.25 17.9288 7.41 23.5513 13 24.9163C18.59 23.5513 22.75 17.9288 22.75 11.9163V6.82467C22.75 5.96884 22.2408 5.18884 21.4608 4.84217L13.8775 1.47301C13.325 1.22384 12.675 1.22384 12.1225 1.47301ZM10.0642 17.6472L7.25833 14.8413C6.83583 14.4188 6.83583 13.7363 7.25833 13.3138C7.68083 12.8913 8.36333 12.8913 8.78583 13.3138L10.8333 15.3505L17.2033 8.98051C17.6258 8.55801 18.3083 8.55801 18.7308 8.98051C19.1533 9.40301 19.1533 10.0855 18.7308 10.508L11.5917 17.6472C11.18 18.0697 10.4867 18.0697 10.0642 17.6472Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42750">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M3S1', name: 'Dashboard', url: 'eligiblity/dashboard', icon: '' },
                { id: 'M3S2', name: 'Pending', url: 'eligiblity/pending', icon: '' },
                { id: 'M3S3', name: 'Verified', url: 'eligiblity/verified', icon: '' },
            ]
        },
        {
            id: 'M4', name: 'Engagement', icon: `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42753)">
                <path
                    d="M23.8333 9.74967V8.66634C23.8333 8.07051 23.3458 7.58301 22.75 7.58301C22.1542 7.58301 21.6667 8.07051 21.6667 8.66634V9.74967H20.5833C19.9875 9.74967 19.5 10.2372 19.5 10.833C19.5 11.4288 19.9875 11.9163 20.5833 11.9163H21.6667V12.9997C21.6667 13.5955 22.1542 14.083 22.75 14.083C23.3458 14.083 23.8333 13.5955 23.8333 12.9997V11.9163H24.9167C25.5125 11.9163 26 11.4288 26 10.833C26 10.2372 25.5125 9.74967 24.9167 9.74967H23.8333Z"
                    fill="white" />
                <path
                    d="M8.66665 12.9997C11.0608 12.9997 13 11.0605 13 8.66634C13 6.27217 11.0608 4.33301 8.66665 4.33301C6.27248 4.33301 4.33331 6.27217 4.33331 8.66634C4.33331 11.0605 6.27248 12.9997 8.66665 12.9997Z"
                    fill="white" />
                <path
                    d="M8.66667 14.083C5.77417 14.083 0 15.5347 0 18.4163V21.6663H17.3333V18.4163C17.3333 15.5347 11.5592 14.083 8.66667 14.083Z"
                    fill="white" />
                <path
                    d="M13.5525 4.38672C14.5492 5.53505 15.1667 7.03005 15.1667 8.66588C15.1667 10.3017 14.5492 11.7967 13.5525 12.9451C15.6758 12.6742 17.3333 10.8759 17.3333 8.66588C17.3333 6.45589 15.6758 4.65755 13.5525 4.38672Z"
                    fill="white" />
                <path
                    d="M17.9075 14.9824C18.8716 15.8816 19.5 17.0083 19.5 18.4166V21.6666H21.6666V18.4166C21.6666 16.8458 19.9441 15.6974 17.9075 14.9824Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42753">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M4S1', name: 'Dashboard', url: 'engagement/dashboard', icon: '' },
                { id: 'M4S2', name: 'Pending', url: 'engagement/pending', icon: '' },
                { id: 'M4S3', name: 'Verified', url: 'engagement/verified', icon: '' },
            ]
        },
        {
            id: 'M5', name: 'Forms', icon: ` <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42764)">
                <path
                    d="M15.8058 2.80616C15.3941 2.39449 14.8416 2.16699 14.2675 2.16699H6.49998C5.30831 2.16699 4.33331 3.14199 4.33331 4.33366V21.667C4.33331 22.8587 5.29748 23.8337 6.48915 23.8337H19.5C20.6916 23.8337 21.6666 22.8587 21.6666 21.667V9.56616C21.6666 8.99199 21.4391 8.43949 21.0275 8.03866L15.8058 2.80616ZM16.25 19.5003H9.74998C9.15415 19.5003 8.66665 19.0128 8.66665 18.417C8.66665 17.8212 9.15415 17.3337 9.74998 17.3337H16.25C16.8458 17.3337 17.3333 17.8212 17.3333 18.417C17.3333 19.0128 16.8458 19.5003 16.25 19.5003ZM16.25 15.167H9.74998C9.15415 15.167 8.66665 14.6795 8.66665 14.0837C8.66665 13.4878 9.15415 13.0003 9.74998 13.0003H16.25C16.8458 13.0003 17.3333 13.4878 17.3333 14.0837C17.3333 14.6795 16.8458 15.167 16.25 15.167ZM14.0833 8.66699V3.79199L20.0416 9.75033H15.1666C14.5708 9.75033 14.0833 9.26283 14.0833 8.66699Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42764">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M5S1', name: 'Dashboard', url: 'forms/dashboard', icon: '' },
                { id: 'M5S2', name: 'Forms', url: 'forms/forms', icon: '' },
            ]
        },
        {
            id: 'M6', name: 'Messaging', icon: `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42767)">
                <path
                    d="M21.6667 4.33301H4.33335C3.14169 4.33301 2.17752 5.30801 2.17752 6.49967L2.16669 19.4997C2.16669 20.6913 3.14169 21.6663 4.33335 21.6663H21.6667C22.8584 21.6663 23.8334 20.6913 23.8334 19.4997V6.49967C23.8334 5.30801 22.8584 4.33301 21.6667 4.33301ZM21.2334 8.93717L13.5742 13.7255C13.2275 13.9422 12.7725 13.9422 12.4259 13.7255L4.76669 8.93717C4.49585 8.76384 4.33335 8.47134 4.33335 8.15717C4.33335 7.43134 5.12419 6.99801 5.74169 7.37717L13 11.9163L20.2584 7.37717C20.8759 6.99801 21.6667 7.43134 21.6667 8.15717C21.6667 8.47134 21.5042 8.76384 21.2334 8.93717Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42767">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M6S1', name: 'Inbox', url: 'messaging/inbox', icon: '' },
                { id: 'M6S2', name: 'Mass SMS', url: 'messaging/mass-sms', icon: '' },
            ]
        },

        {
            id: 'M7', name: 'Payments', icon: `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5">
                <rect x="2.16797" y="5.77344" width="21.6667" height="14.4444" rx="1.5" fill="white" />
                <rect x="4.23047" y="15.5781" width="5.15873" height="1.54762" rx="0.77381"
                    fill="#343D56" />
                <rect x="10.4219" y="15.5781" width="5.15873" height="1.54762" rx="0.77381"
                    fill="#343D56" />
                <rect x="16.6094" y="15.5781" width="5.15873" height="1.54762" rx="0.77381"
                    fill="#343D56" />
                <rect x="4.23029" y="9.90039" width="3.25" height="2.16667" rx="0.5" fill="#343D56" />
            </g>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M7S1', name: 'Dashboard', url: 'payments/dashboard', icon: '' },
                { id: 'M7S2', name: 'Pending', url: 'payments/pending', icon: '' },
                { id: 'M7S3', name: 'Completed', url: 'payments/completed', icon: '' },
                { id: 'M7S4', name: 'Recurring', url: 'payments/recurring', icon: '' },
                { id: 'M7S5', name: 'Transactions', url: 'payments/transactions', icon: '' },
            ]
        },
        {
            id: 'M9', name: 'Review', icon: `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5" clip-path="url(#clip0_12118_42779)">
                <path
                    d="M13 18.7091L17.4958 21.4282C18.3192 21.9266 19.3267 21.1899 19.11 20.2582L17.9184 15.1449L21.8942 11.6999C22.62 11.0716 22.23 9.87991 21.2767 9.80408L16.0442 9.35991L13.9967 4.52824C13.6284 3.65074 12.3717 3.65074 12.0034 4.52824L9.95585 9.34908L4.72335 9.79324C3.77002 9.86908 3.38002 11.0607 4.10585 11.6891L8.08168 15.1341L6.89002 20.2474C6.67335 21.1791 7.68085 21.9157 8.50418 21.4174L13 18.7091Z"
                    fill="white" />
            </g>
            <defs>
                <clipPath id="clip0_12118_42779">
                    <rect width="26" height="26" fill="white" />
                </clipPath>
            </defs>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M9S1', name: 'Reviews', url: 'reviews/reviews', icon: '' },
            ]
        },
        {
            id: 'M8', name: 'Treatment', icon: ` <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.5">
                <mask id="mask0_12118_42785" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="4" y="4"
                    width="18" height="18">
                    <rect x="4" y="4" width="18" height="18" fill="white" />
                </mask>
                <g mask="url(#mask0_12118_42785)">
                    <path
                        d="M20.7467 6.00052C19.7839 4.70338 18.7725 4.09925 17.5636 4.09925C16.7809 4.09925 16.0215 4.35028 15.2883 4.59252L15.264 4.60051C14.4819 4.85735 13.7431 5.10009 12.9459 5.10009C12.1471 5.10009 11.3642 4.83733 10.6021 4.58177C9.85456 4.33311 9.08167 4.07617 8.30798 4.07617C7.09311 4.07617 6.10539 4.69254 5.20003 6.01522C3.77585 8.08939 4.58445 10.3105 5.23672 12.1018C5.5272 12.8988 5.8015 13.6515 5.8015 14.2198C5.8015 17.1379 6.41688 22.0762 8.72343 22.0762C10.302 22.0762 10.7876 20.2421 11.2173 18.6193C11.6735 16.9111 12.0685 15.702 13.002 15.702C13.8073 15.702 14.1155 16.4848 14.5426 18.3615C14.9123 20.0012 15.3723 22.0417 17.3124 22.0417C20.0194 22.0417 20.2298 16.0518 20.2298 14.216C20.2298 13.6772 20.495 12.9308 20.7759 12.1406L20.7871 12.109C21.4333 10.2808 22.2376 8.00575 20.7467 6.00052ZM19.3922 11.6158L19.3819 11.645C19.0571 12.5589 18.7504 13.422 18.7504 14.2159C18.7504 15.9583 18.5671 17.6472 18.2474 18.8497C17.874 20.2544 17.4458 20.562 17.3124 20.562C16.7182 20.562 16.4331 20.0191 15.9844 18.029C15.6186 16.4225 15.1179 14.2222 13.002 14.2222C10.8602 14.2222 10.2404 16.5429 9.78592 18.2451C9.53795 19.1815 9.16334 20.5965 8.72353 20.5965C8.65527 20.5965 8.22553 20.2998 7.83208 18.8898C7.48193 17.6352 7.28121 15.933 7.28121 14.2196C7.28121 13.3901 6.96341 12.5182 6.6248 11.589C6.03585 9.97152 5.42689 8.29889 6.42053 6.85173C7.202 5.70965 7.81324 5.55568 8.30798 5.55568C8.84219 5.55568 9.47029 5.76449 10.1363 5.98592C10.9656 6.26417 11.9055 6.5796 12.9459 6.5796C13.9796 6.5796 14.9073 6.27502 15.7257 6.00624L15.7512 5.99786C16.4032 5.78234 17.0191 5.57886 17.5636 5.57886C18.0717 5.57886 18.7061 5.73371 19.5591 6.8829C20.58 8.25588 19.9762 9.96403 19.3922 11.6158Z"
                        fill="white" />
                    <path
                        d="M7.07331 5.66334C5.08905 6.73887 4.82263 9.61128 5.87285 11.4336C6.17599 11.9596 6.37355 13.8942 6.37355 13.8942C6.37355 13.8942 6.22558 20.6186 8.69373 20.6738C11.6876 20.7407 9.96704 14.7165 12.9534 14.4938C16.1159 14.258 15.3576 20.6738 17.2737 20.6738C19.1899 20.6738 18.5917 15.8555 18.9104 13.1994C19.003 12.4276 19.419 12.0619 19.6367 11.6205C20.1682 10.5427 20.6482 9.94045 20.5734 8.61433C20.468 6.74502 19.7043 6.35545 18.4699 5.66343C16.5459 4.58492 15.1586 6.43409 12.9534 6.39368C10.9177 6.35637 8.86327 4.69313 7.07331 5.66334Z"
                        fill="white" />
                </g>
            </g>
        </svg>`, isSidebar: true, url: '', submenu: [
                { id: 'M7S1', name: 'Dashboard', url: 'treatment/dashboard', icon: '' },
                { id: 'M7S2', name: 'Pending', url: 'payments/pending', icon: '' },
                { id: 'M7S3', name: 'Completed', url: 'payments/completed', icon: '' },
                { id: 'M7S4', name: 'Recurring', url: 'payments/recurring', icon: '' },
                { id: 'M7S5', name: 'Transactions', url: 'payments/transactions', icon: '' },
            ]
        },

        {
            id: 'M10', name: 'Settings', icon: '', isSidebar: false, url: '', submenu: [
                { id: 'M10S11', name: 'Users', url: 'settings/users', icon: '', subtopbar: SubTopbarWithFilterComponent },
                { id: 'M10S7', name: 'Practices', url: 'settings/practices', icon: '' },
                { id: 'M10S1', name: 'Eligiblity', url: 'settings/eligibility', icon: '' },
                { id: 'M10S2', name: 'Engagement', url: 'settings/engagement', icon: '' },
                { id: 'M10S3', name: 'Forms', url: 'settings/forms', icon: '' },
                { id: 'M10S4', name: 'Goals', url: 'settings/goals', icon: '' },
                { id: 'M10S5', name: 'Messaging', url: 'settings/messaging', icon: '' },
                { id: 'M10S6', name: 'Payments', url: 'settings/payements', icon: '' },
                { id: 'M10S8', name: 'Reviews', url: 'settings/reviews', icon: '' },
                { id: 'M10S9', name: 'Scheduling', url: 'settings/schedule', icon: '' },
                { id: 'M10S10', name: 'Treatment', url: 'settings/treatment', icon: '' },
            ]
        },
    ];
}