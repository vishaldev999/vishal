import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-sub-topbar',
  templateUrl: './sub-topbar.component.html',
  styleUrls: ['./sub-topbar.component.scss']
})
export class SubTopbarComponent {
   

  selectedPractice:any= null;
  selectedRegion:any= null;
  date!: Date[];
  practiceList = [
    {
      practiceName: 'Brooks-Ortho',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Brooks-Pedo',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Cibolo-Ortho',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Cibolo-Pedo',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Culebra-Ortho',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    },
    {
      practiceName: 'Culebra-Pedo',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    }
  ];

  regionsList = [
    {
      regionsName: 'Texas',
      regionsLoc: '12 location'
    },
    {
      regionsName: 'TX',
      regionsLoc: '9 location'
    },
  ];
  
}
