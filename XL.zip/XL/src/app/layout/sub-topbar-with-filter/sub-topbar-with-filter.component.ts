import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-topbar-with-filter',
  templateUrl: './sub-topbar-with-filter.component.html',
  styleUrls: ['./sub-topbar-with-filter.component.scss']
})
export class SubTopbarWithFilterComponent implements OnInit {
  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];

  cities: any[] = [];
  selectedCities: any[] = [];

  filterUsers(event:any) {
    let filtered: any[] = [];
        let query = event.query;
        console.log(event)
        filtered = this.users.filter((e:any)=>{ return e.name.toLowerCase().indexOf(query.toLowerCase())!=-1});
        console.log(filtered)
        this.filteredUsers = filtered;
  }

  ngOnInit() {
    this.users = [
      {
       name:'Ashish Kaushik'
     },
     {
       name:'Nisar'
     },
     {
       name:'Rachel Etherington'
     },
     {
       name:'Anurag'
     },
     {
       name:'Abhishek'
     }
   ];

   this.cities = [
    { name: 'New York', code: 'NY' },
    { name: 'Rome', code: 'RM' },
    { name: 'London', code: 'LDN' },
    { name: 'Istanbul', code: 'IST' },
    { name: 'Paris', code: 'PRS' }
  ];
  }
}
