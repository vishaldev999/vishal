import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MenuClass } from '../menu';
import { Router } from '@angular/router';
import { CurrentMenuService } from 'src/app/shared/services/current-menu.service';

@Component({
  selector: 'app-left-sidebar',
  templateUrl: './left-sidebar.component.html',
  styleUrls: ['./left-sidebar.component.scss']
})
export class LeftSidebarComponent implements OnInit {

  fullwidth: boolean = false;
  menuList: any = [];
  navValue: string = "";
  menu: string = '';

  @Output() fullwidthEvent = new EventEmitter<boolean>(); 

  constructor(private router: Router, private currentMenuService: CurrentMenuService) {
    this.menuList = new MenuClass().menuList.
      filter((e: any) => { return e.isSidebar == true });
  }

  ngOnInit(): void {

  }

  expandDropdown(navitem: string) {
    if (this.navValue == navitem)
      this.navValue = "";
    else
      this.navValue = navitem;
  }

  menuSelection(navitem: string, menu: string = '') {
    this.navValue = navitem;
    this.menu = menu;
    this.currentMenuService.setParent(navitem);
    this.currentMenuService.setMenu(menu);
  }

  toggleFullWidth() {
    this.fullwidth = !this.fullwidth;
    this.fullwidthEvent.emit(this.fullwidth);
  }
}

