import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router'; 
import { MessageService } from 'primeng/api';

@Injectable({ providedIn: "root" })
export class ErrorInterceptor implements HttpInterceptor {

  constructor(private router: Router,   private messageService: MessageService) {
  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      catchError((response: HttpErrorResponse) => {
        switch (response.status) {
          case 400:
            if (response.error?.errors[""]?.length > 0) {
              response.error?.errors[""]?.forEach((err: String) => {
                this.messageService.add({ severity: 'error', summary: `${response.error?.title}`, detail: `${err}` });
              });
            }
            else {
              this.messageService.add({ severity: 'error', summary: 'Error', detail: `${response.error.errors[""][0]}` });
            }
            break;
          case 401:
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Authentication Failed' });
            break;
          case 403:
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Forbidden' });
            break;
          case 404:
            this.messageService.add({ severity: 'error', summary: 'Error', detail: `Not Found.` });
            break;
          case 500:
            if (response.error?.messages.length > 0) {
              response.error?.messages.forEach((err: String) => {
                this.messageService.add({ severity: 'error', summary: `Error`, detail: `${err}` });
              });
            }
            else {
              this.messageService.add({ severity: 'error', summary: 'Error', detail: `${response.error?.exception}` });
            }
            break;
        }
        return throwError(response.error);
      })
    );
  }
}
